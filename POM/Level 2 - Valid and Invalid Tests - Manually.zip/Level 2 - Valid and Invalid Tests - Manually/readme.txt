this level has valid and invalid test case

If you want to run the test then open testng.xml and right click and select run as Test Suite or F6 (my custom setting) in eclipse.
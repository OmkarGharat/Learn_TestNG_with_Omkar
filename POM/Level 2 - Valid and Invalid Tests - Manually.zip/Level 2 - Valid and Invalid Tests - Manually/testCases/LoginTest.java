package testCases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.LoginPage;

public class LoginTest extends BaseTest {

	// optional
//	@BeforeMethod
//	public void resetState() {
//		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
//	}

	@AfterMethod
	public void cleanupState() {
		driver.manage().deleteAllCookies(); // removes login session
		driver.navigate().refresh(); // page refresh होईल
	}

	@Test(priority = 1)
	public void testValidLogin() {

		LoginPage login = new LoginPage(driver);
		login.enterUsername("Admin");
		System.out.println("username assignation completed...");

		login.enterPassword("admin123");
		System.out.println("password assignation completed...");

		login.clickLogin();
		System.out.println("Login Successful");
	}

	@Test(priority = 2)
	public void testInvalidLogin() {

		LoginPage login = new LoginPage(driver);

		// 1. wrong credentials

		login.enterUsername("abc");
		System.out.println("username is entered in field");

		login.enterPassword("admin@123");
		System.out.println("password is entered in field");

		login.clickLogin();
		System.out.println("login btn is clicked");
		
		System.out.println(login.getErrorMessage());
		
		Assert.fail(login.getErrorMessage());

//		String expectedErrorMsg = "Invalid credentials";
//		String actualErrorMsg = login.getErrorMessage();
//
//		System.out.println("Error: " + login.getErrorMessage());
//
//		Assert.assertEquals(actualErrorMsg, expectedErrorMsg, "Invalid Credentials, cannot proceed.");
	}
}

package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utility.Utility;

public class LoginPage {

	WebDriver driver;
//	WebDriverWait wait;

	// Constructor

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this); // Initialize @FindBy elements
	}

	@FindBy(xpath = "//input[@placeholder='Username']")
	WebElement usernameField;

	@FindBy(xpath = "//input[@placeholder='Password']")
	WebElement passwordField;

	@FindBy(xpath = "//button[contains(@class, 'orangehrm-login-button')]")
	WebElement loginButton;

	@FindBy(xpath = "//p[contains(@class, 'oxd-alert-content-text')]")
	WebElement errorMsg;

	@FindBy(xpath = "//li[@class='oxd-userdropdown']")
	WebElement logoutDropDown;

	@FindBy(xpath = "//a[normalize-space()='Logout']")
	WebElement logoutBtn;

	// Actions class

	Utility utility = new Utility();

	public void enterUsername(String username) {

		utility.waitForVisibility(usernameField);
		usernameField.sendKeys(username);
		System.out.println("username : " + username + " is assigned...");
	}

	public void enterPassword(String password) {

		utility.waitForVisibility(passwordField);
		passwordField.sendKeys(password);
		System.out.println("password : " + password + " is assigned...");
	}

	public void clickLogin() {
		loginButton.click();
	}

	public String getErrorMessage() {

		utility.waitForVisibility(errorMsg);
//		System.out.println("getErrorMessage : " + errorMsg.getText() + " is assigned...");
		return errorMsg.getText();
	}

//	public void clickLogoutdropDown() {
//		utility.waitForVisibility(logoutDropDown);
//
//		logoutDropDown.click();
//		System.out.println("Clicked on Logout Dropdown");
//	}
//
//	public void clickLogout() {
//		utility.waitForVisibility(logoutBtn);
//
//		logoutBtn.click();
//		System.out.println("Clicked on Logout");
//	}

}

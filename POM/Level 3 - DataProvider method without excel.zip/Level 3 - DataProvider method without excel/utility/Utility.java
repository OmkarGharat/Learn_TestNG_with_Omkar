package utility;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Utility {

	// ask amu, why private variables
	private WebDriver driver;
	private WebDriverWait wait;

	// ask amu why constructor
	Utility(WebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	}

	public WebDriverWait waitForSeconds(int waitTime) {

		if (waitTime <= 0 || waitTime > 60) {
			return new WebDriverWait(driver, Duration.ofSeconds(10));
		}

		wait = new WebDriverWait(driver, Duration.ofSeconds(waitTime));
		return wait;
	}

	// Wait for the page to load completely
	public void waitForPageToLoad() {
		wait.until(webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState")
				.equals("complete"));
	}

	// wait for the each Individual elements to load completely
	public void waitForVisibility(WebElement element) {
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public void waitForClickability(WebElement element) {
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}

}
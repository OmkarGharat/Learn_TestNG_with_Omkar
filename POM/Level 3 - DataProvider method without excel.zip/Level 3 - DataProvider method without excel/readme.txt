this level has all valid and invalid test cases of login through data provider method but not through excel. That is still pending.

If you want to run the test then open testng.xml and right click and select run as Test Suite or F6 (my custom setting) in eclipse.
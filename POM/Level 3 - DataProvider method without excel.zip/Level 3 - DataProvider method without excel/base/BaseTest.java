package base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import utility.Utility;

public class BaseTest {

	protected WebDriver driver;
	protected Utility utils;

	@BeforeClass
	public void setup() {
		System.out.println("Test Execution Started...");

		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		System.out.println("Browser Lanuched...");
	}

	@AfterClass
	public void tearDown() {
		System.out.println("Test Execution Completed...");

		if (driver != null) {
			this.driver = null;
			driver.quit();
		}
	}
}

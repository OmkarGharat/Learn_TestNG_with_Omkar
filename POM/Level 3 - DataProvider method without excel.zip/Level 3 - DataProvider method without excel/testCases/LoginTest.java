package testCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.LoginPage;
import utility.Utility;

public class LoginTest extends BaseTest {
	
	protected WebDriver driver;
	protected Utility utils;

	@AfterMethod
	public void cleanupState() {
		driver.manage().deleteAllCookies(); // removes login session
		driver.navigate().refresh(); // page refresh होईल
	}

	@DataProvider(name = "loginData")
	public Object[][] loginTestData() {
		return new Object[][] { 
			{ "Admin", "admin123", "valid" }, 
			{ "Admin", "admin@123", "invalid" },
			{ "systemUser", "admin123", "invalid" }, 
			{ "", "", "invalid" }, 
			{ "admin!@#", "pass@123", "invalid" } };
	}

	@Test(priority = 1, dataProvider = "loginData")
	public void testLogin(String username, String password, String expectedResult) {

		LoginPage login = new LoginPage(driver);
		login.enterUsername(username);
		login.enterPassword(password);
		login.clickLogin();
		
		// Imported from Utility class
		WebDriverWait wait = utils.waitForSeconds(10);
		
		String expectedURL = "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index";
		
		if (expectedResult.equals("valid")) {
			
			wait.until(ExpectedConditions.urlToBe(expectedURL));
			String actualURL = driver.getCurrentUrl();
			
			Assert.assertEquals(actualURL, expectedURL, "Valid Login Failed Unexpectedly...");
			
			System.out.println("Login Successful with Username: " + username + " and Password: " + password);
			login.clickLogoutdropDown();
			login.clickLogout();
			
		}else {
			
			wait.until(ExpectedConditions.visibilityOf(login.getErrorMessageElement()));
			
			String actualErrorMsg = login.getErrorMessageElement().getText();
	        String expectedErrorMsg = "Invalid credentials"; // or as per actual site text
	        
	        System.out.println("❌ Login failed with: " + username + " | " + actualErrorMsg);
	        Assert.assertEquals(actualErrorMsg, expectedErrorMsg, "❌ Error message mismatched.");
		}		
	}
}
